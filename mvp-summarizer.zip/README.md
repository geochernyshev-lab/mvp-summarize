# MVP Summarizer (Next.js + Supabase)

- Email/пароль вход, сброс пароля (Supabase Auth)
- Загрузка PDF ≤ 5 страниц
- Лимит: 20 загрузок/пользователь
- История запросов/ответов
- Деплой: Vercel + Supabase (free)
