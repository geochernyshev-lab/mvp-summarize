export default function Home() {
  return (
    <div className="grid">
      <h1>Краткий конспект PDF за секунды</h1>
      <p className="small">Залогиньтесь, загрузите документ (до 5 страниц) — получите суть на языке документа.</p>
      <a href="/signup"><button>Начать бесплатно</button></a>
    </div>
  );
}
