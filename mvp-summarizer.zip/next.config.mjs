const nextConfig = {
  experimental: { serverActions: { allowedOrigins: ["*"] } },
};
export default nextConfig;
